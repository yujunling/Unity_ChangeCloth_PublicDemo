﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShareMeshBuildingSpace : MonoBehaviour
{
	/// <summary>
	/// 构建的角色id，可以选择 0和1
	/// </summary>
	public int CharacterID = 0;

	public Camera CharacterCamera;
	
	private GameObject m_Character;
	private const int COMBINE_TEXTURE_MAX = 256;
	private const string COMBINE_DIFFUSE_TEXTURE = "_MainTex";
    // Start is called before the first frame update
    void Start()
    {
	    BuildCharacter();
    }
     public void BuildCharacter()
    {
        if (m_Character != null)
        {
            GameObject.DestroyImmediate(m_Character);
        }
        var boneName ="cm_alice_bone";
        var chaPrefab = Resources.Load<GameObject>("CharacterCloth/cm_alice/" + boneName);
        var cha = GameObject.Instantiate(chaPrefab,this.transform);
        cha.name =boneName;
        m_Character = cha;
        var rotateModel=m_Character.AddComponent<RotateModel>();
        rotateModel.RayCamera = this.CharacterCamera;
        cha.transform.localPosition=new Vector3(0,0.5f,0);
        cha.transform.localScale=Vector3.one;
        cha.transform.localRotation=Quaternion.Euler(0,180,0);
        
        var rigidbody = m_Character.AddComponent<Rigidbody>();
        rigidbody.useGravity = false;
        m_Character.AddComponent<BoxCollider>();
        SkinnedMeshRenderer[] meshes = new SkinnedMeshRenderer[4];
        GameObject[] objects = new GameObject[4];
        var chaOwnedClothList=CreateTestCharacterData();
        var clothPath = "CharacterCloth/cm_alice/" + (CharacterID == 0 ? "cm_alice_000" : "cm_alice_001");
        for (var i = 0; i < chaOwnedClothList.Count; i++)
        {
	        var res = Resources.Load<GameObject>( clothPath+ "/"+chaOwnedClothList[i]);; // Resources.Load ("Prefab/" + equipments [i]);
	        if (res != null)
	        {
		        objects[i] = GameObject.Instantiate(res, this.transform) as GameObject;
		        meshes[i] = objects[i].GetComponentInChildren<SkinnedMeshRenderer>();
	        }
	        else
	        {
		        Debug.Log("Cloth Config Error: prefab "+clothPath+ boneName);
	        }
        }
        CombineObject(cha, meshes, false);
        ReleaseClothAssets(objects);
    }

     private List<string> CreateTestCharacterData()
     {
	     var result=new List<string>();
	     switch (this.CharacterID)
	     {
		     case 0:
			     result.Add("cm_alice_000_hair");
			     result.Add("cm_alice_000_pants");
			     result.Add("cm_alice_000_shoes");
			     result.Add("cm_alice_000_t-shirt");
			     break;
		     case 1:
			     result.Add("cm_alice_001_hair");
			     result.Add("cm_alice_001_pants");
			     result.Add("cm_alice_001_shoes");
			     result.Add("cm_alice_001_t-shirt");
			     break;
	     }
	     return result;
     }

     public void CombineObject(GameObject skeleton, SkinnedMeshRenderer[] meshes, bool combine = false)
    {
	    // Fetch all bones of the skeleton
		List<Transform> transforms = new List<Transform>();
		transforms.AddRange(skeleton.GetComponentsInChildren<Transform>(true));

		List<Material> materials = new List<Material>();//the list of materials
		List<CombineInstance> combineInstances = new List<CombineInstance>();//the list of meshes
		List<Transform> bones = new List<Transform>();//the list of bones
		// Below informations only are used for merge materilas(bool combine = true)
		List<Vector2[]> oldUV = null;
		Material newMaterial = null;
		Texture2D newDiffuseTex = null;

		// Collect information from meshes
		for (int i = 0; i < meshes.Length; i ++)
		{
			SkinnedMeshRenderer smr = meshes[i];
			materials.AddRange(smr.materials); // Collect materials
			// Collect meshes
			for (int sub = 0; sub < smr.sharedMesh.subMeshCount; sub++)
			{
				CombineInstance ci = new CombineInstance();
				ci.mesh = smr.sharedMesh;
				ci.subMeshIndex = sub;
				combineInstances.Add(ci);
			}
			// Collect bones
			for (int j = 0 ; j < smr.bones.Length; j ++)
			{
				int tBase = 0;
				for (tBase = 0; tBase < transforms.Count; tBase ++)
				{
					if (smr.bones[j].name.Equals(transforms[tBase].name))
					{
						bones.Add(transforms[tBase]);
						break;
					}
				}
			}
		}

        // merge materials
		if (combine)
		{
			newMaterial = new Material (Shader.Find ("Unlit/TextureColor"));
			oldUV = new List<Vector2[]>();
			// merge the texture
			List<Texture2D> Textures = new List<Texture2D>();
			for (int i = 0; i < materials.Count; i++)
			{
				Textures.Add(materials[i].GetTexture(COMBINE_DIFFUSE_TEXTURE) as Texture2D);
			}

			newDiffuseTex = new Texture2D(COMBINE_TEXTURE_MAX, COMBINE_TEXTURE_MAX, TextureFormat.RGBA32, true);
			Rect[] uvs = newDiffuseTex.PackTextures(Textures.ToArray(), 0);
			newMaterial.mainTexture = newDiffuseTex;
			// reset uv
			Vector2[] uva, uvb;
			for (int j = 0; j < combineInstances.Count; j++)
			{
				uva = (Vector2[])(combineInstances[j].mesh.uv);
				uvb = new Vector2[uva.Length];
				for (int k = 0; k < uva.Length; k++)
				{
					uvb[k] = new Vector2((uva[k].x * uvs[j].width) + uvs[j].x, (uva[k].y * uvs[j].height) + uvs[j].y);
				}
				oldUV.Add(combineInstances[j].mesh.uv);
				combineInstances[j].mesh.uv = uvb;
			}
		}
		// Create a new SkinnedMeshRenderer
		SkinnedMeshRenderer oldSKinned = skeleton.GetComponent<SkinnedMeshRenderer> ();
		if (oldSKinned != null) {
			GameObject.DestroyImmediate (oldSKinned);
		}
		SkinnedMeshRenderer r = skeleton.AddComponent<SkinnedMeshRenderer>();
		r.sharedMesh = new Mesh();
		r.sharedMesh.CombineMeshes(combineInstances.ToArray(), combine, false);// Combine meshes
		r.bones = bones.ToArray();// Use new bones
		if (combine)
		{
			r.material = newMaterial;
			for (int i = 0 ; i < combineInstances.Count ; i ++)
			{
				combineInstances[i].mesh.uv = oldUV[i];
			}
		}else
		{   
			r.materials = materials.ToArray();
		}
    }
     private void ReleaseClothAssets( GameObject[] objects)
     {
	     for (var i = 0; i < objects.Length; i++)
	     {
		     GameObject.DestroyImmediate(objects[i].gameObject);
	     }
	     Resources.UnloadUnusedAssets();
     }
}

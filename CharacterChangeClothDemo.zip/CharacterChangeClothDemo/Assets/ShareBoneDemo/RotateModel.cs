﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateModel : MonoBehaviour
{
    private float RotateSpeed = 100;
    private bool canRotate = false;
    public Camera RayCamera;
    void Update()
    {
        if (RayCamera == null)
        {
            return;
        }
        //手指按下,并且选中物体是角色
        if (!canRotate&&Input.GetMouseButtonDown(0))
        {
            Ray ray = RayCamera.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.gameObject == this.gameObject)
                {
                    canRotate = true;
                }
            }
        }

#if UNITY_EDITOR
        //手指滑动
        if (canRotate &&Input.GetAxis("Mouse X") != 0)
        {
            
            this.transform.Rotate(Vector3.up * -Input.GetAxis("Mouse X")*RotateSpeed*Time.deltaTime,Space.Self);
        }
#else
        if (canRotate &&Input.touchCount == 1&&Input.GetTouch(0).phase == TouchPhase.Moved)
        {
            this.transform.Rotate(Vector3.up*-Input.GetAxis("Mouse X")*RotateSpeed*Time.deltaTime,Space.Self);
        }
#endif


        //手指松开处理
        if (Input.GetMouseButtonUp(0))
        {
            canRotate = false;
        }
    }
}

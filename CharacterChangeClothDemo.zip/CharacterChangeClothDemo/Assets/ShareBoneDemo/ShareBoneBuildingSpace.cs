﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShareBoneBuildingSpace : MonoBehaviour
{
	/// <summary>
	/// 构建的角色id，可以选择 0和1
	/// </summary>
	public int CharacterID = 0;

	public Camera CharacterCamera;
	
	private GameObject m_Character;
	private const int COMBINE_TEXTURE_MAX = 256;
	private const string COMBINE_DIFFUSE_TEXTURE = "_MainTex";
	private Transform[] _skeletonHipsAry;
	private int[] _skeletonHipsNameAry;
    void Start()
    {
	    BuildCharacter();
    }
     public void BuildCharacter()
    {
        if (m_Character != null)
        {
            GameObject.DestroyImmediate(m_Character);
        }
        var boneName ="cm_alice_bone";
        var chaPrefab = Resources.Load<GameObject>("CharacterCloth/cm_alice/" + boneName);
        var cha = GameObject.Instantiate(chaPrefab,this.transform);
         if (_skeletonHipsAry == null)
	         _skeletonHipsAry = cha.transform.Find("Bip001").GetComponentsInChildren<Transform>();

         _skeletonHipsNameAry = new int[_skeletonHipsAry.Length]; //遍历所有的节点 
         for (int i = 0; i < _skeletonHipsAry.Length; ++i)
         {
	         _skeletonHipsNameAry[i] = Animator.StringToHash(_skeletonHipsAry[i].name);
         }
         
        cha.name =boneName;
        m_Character = cha;
        var rotateModel=m_Character.AddComponent<RotateModel>();
        rotateModel.RayCamera = this.CharacterCamera;
        cha.transform.localPosition=new Vector3(0,0.5f,0);
        cha.transform.localScale=Vector3.one;
        cha.transform.localRotation=Quaternion.Euler(0,180,0);
        
        var rigidbody = m_Character.AddComponent<Rigidbody>();
        rigidbody.useGravity = false;
        m_Character.AddComponent<BoxCollider>();
        SkinnedMeshRenderer[] meshes = new SkinnedMeshRenderer[4];
        GameObject[] objects = new GameObject[4];
        var chaOwnedClothList=CreateTestCharacterData();
        var clothPath = "CharacterCloth/cm_alice/" + (CharacterID == 0 ? "cm_alice_000" : "cm_alice_001");
        for (var i = 0; i < chaOwnedClothList.Count; i++)
        {
	        var res = Resources.Load<GameObject>( clothPath+ "/"+chaOwnedClothList[i]);; // Resources.Load ("Prefab/" + equipments [i]);
	        if (res != null)
	        {
		        //objects[i] = GameObject.Instantiate(res, this.transform) as GameObject;
		        meshes[i] = res.GetComponentInChildren<SkinnedMeshRenderer>();
	        }
	        else
	        {
		        Debug.Log("Cloth Config Error: prefab "+clothPath+ boneName);
	        }
        }
        CombineObject(cha, meshes, false);
       // ReleaseClothAssets(objects);
    }

     private List<string> CreateTestCharacterData()
     {
	     var result=new List<string>();
	     switch (this.CharacterID)
	     {
		     case 0:
			     result.Add("cm_alice_000_hair");
			     result.Add("cm_alice_000_pants");
			     result.Add("cm_alice_000_shoes");
			     result.Add("cm_alice_000_t-shirt");
			     break;
		     case 1:
			     result.Add("cm_alice_001_hair");
			     result.Add("cm_alice_001_pants");
			     result.Add("cm_alice_001_shoes");
			     result.Add("cm_alice_001_t-shirt");
			     break;
	     }
	     return result;
     }
    
     public void CombineObject(GameObject skeleton, SkinnedMeshRenderer[] meshes, bool combine = false)
    {
	    for (var i = 0; i < meshes.Length; i++)
	    {
		    var bones=new List<Transform>();
		    for (int j = 0 ; j < meshes[i].bones.Length; j ++)
		    {
			    int tBase = 0;
			    for (tBase = 0; tBase < this._skeletonHipsAry.Length; tBase ++)
			    {
				    if ( meshes[i].bones[j].name.Equals(_skeletonHipsAry[tBase].name))
				    {
					    bones.Add(_skeletonHipsAry[tBase]);
					    break;
				    }
			    }
		    }
		    GameObject go = new GameObject(meshes[i].name);
		    SkinnedMeshRenderer newRend = go.AddComponent<SkinnedMeshRenderer>();
		    newRend.transform.SetParent(skeleton.transform.Find("Bip001"), false);

		    newRend.sharedMesh = meshes[i].sharedMesh;
		    newRend.bones = bones.ToArray();
		    newRend.sharedMaterials = meshes[i].sharedMaterials;// LoadMaterial(pro, fbx_rend.name);

		   // newRend.shadowCastingMode = ShadowCastingMode.Off;
		    newRend.receiveShadows = false;
		  //  newRend.lightProbeUsage = LightProbeUsage.Off;
		  //  newRend.reflectionProbeUsage = ReflectionProbeUsage.Off;

		    //if (!_curMeshes.ContainsKey(pro._id))
			//    _curMeshes.Add(pro._id, new List<GameObject>());
		   // _curMeshes[pro._id].Add(go);
	    }
	    
    }
     private void ReleaseClothAssets( GameObject[] objects)
     {
	     for (var i = 0; i < objects.Length; i++)
	     {
		     GameObject.DestroyImmediate(objects[i].gameObject);
	     }
	     Resources.UnloadUnusedAssets();
     }
}

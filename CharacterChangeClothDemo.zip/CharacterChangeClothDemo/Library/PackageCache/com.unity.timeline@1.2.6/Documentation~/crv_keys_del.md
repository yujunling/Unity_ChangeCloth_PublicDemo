# Deleting keys

The Curves view provides the following methods for deleting keys:

* Right-click a key and select **Delete Key** from the context menu. This method does not affect selected keys.
* Select a key and either press Delete or right-click and select **Delete Key** from the context menu.
